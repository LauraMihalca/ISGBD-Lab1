CREATE PROCEDURE populateDefaultFieldsForD2(IN tablename VARCHAR(25))
  BEGIN
    set @stmt =CONCAT('INSERT INTO ',tablename,
                      ' (parent, c0, k1, c1, k2, c2, k3, c3, k4, c4, nr_key) VALUES',
    ' (NULL, 2, 100, 3, 200, 4, NULL, NULL, NULL, NULL, NULL),
      (1, NULL, 10, NULL, 20, NULL, 30, NULL, NULL, NULL, NULL),
      (1, NULL, 110, NULL, 120, NULL, 130, NULL, 140, NULL, NULL),
      (1, NULL, 210, 4, 220, NULL, 130, NULL, 140, NULL, NULL)');

    PREPARE stmt FROM @stmt;
    EXECUTE stmt;
    SELECT 'Data successfully inserted.';
  END;
