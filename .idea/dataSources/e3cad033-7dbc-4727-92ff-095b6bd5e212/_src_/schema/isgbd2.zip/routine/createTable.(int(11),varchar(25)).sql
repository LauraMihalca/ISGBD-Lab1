CREATE PROCEDURE createTable(IN d INT, IN tablename VARCHAR(25))
  BEGIN
    SET @i = 0;
    SET @stmt = concat('CREATE TABLE ', tablename, ' (id BIGINT auto_increment, parent BIGINT, C0 int');

    REPEAT
      SET @i = @i + 1;
      SET @stmt = concat(@stmt, ',c', @i, ' int, k', @i, ' int');
    UNTIL @i = 2 * d END REPEAT;
    SET @stmt = concat(@stmt, ', nr_key BIGINT, PRIMARY KEY(id))');
    PREPARE stmt FROM @stmt;
    EXECUTE stmt;
  END;
